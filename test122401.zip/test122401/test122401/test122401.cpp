// test122401.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include "Vector.h"
using namespace std;

int main()
{
	Vector v1;
	v1.push_back(111);
	v1.push_back(1);
	v1.push_back(4);
	v1.push_back(99);

	cout << v1 << endl;
	v1[0] = 888;
	cout << "v1.front()=" << v1.front() << endl;
	cout << "v1.back()=" << v1.back() << endl;

	Vector v2;
	v2.push_back(888);
	v2.push_back(1);
	v2.push_back(4);
	v2.push_back(99);
// 	v2 += v1;
// 	cout << "v2 += v1=>" << v2 << endl;
	cout << "v1 + v2=>" << v1 + v2 << endl;
	cout << "v1 == v2=>" << (v1 == v2) << endl;

	cin >> v2;
	cout << "v2=" << v2 << endl;
    return 0;
}

