// test1217.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "Vector.h"
#include <iostream>
using namespace std;
int main()
{
	int p[] = { 1,23,4,6 };
	Vector v1(p, 4);
	v1.output();

	Vector v2 = v1;
	v2.output();
	cout << "v2.size()=" << v2.size() << endl;
    
	v2.push_back(76);
	v2.push_back(54);
	v2.push_back(666);
	

	cout << "v2.at(2)=" << v2.at(2) << endl;
	cout << "v2.front()=" << v2.front() << endl;
	cout << "v2.back()=" << v2.back() << endl;
	cout << "v2.empty()="
		<< boolalpha << v2.empty() << endl;

	cout << "v2.equal()="
		<< boolalpha 
		<< v1.equal(v2) << endl;
	v2.output();
	v2.erase(1000);
	v2.output();

	return 0;
}

