#include "stdafx.h"
#include "String.h"
#include <iostream>

using namespace std;

String::String(char * str)
{
	if (str!=nullptr)
	{
		int len = strlen(str) + 1;
		this->str = new char[len];
		strcpy_s(this->str,len, str);
	}
	else
	{
		this->str = nullptr;
	}
}

String::String(String & other)
	:String(other.str)
{
}

String::~String()
{
	if (str!=nullptr)
	{
		delete[] str;
	}
}

String & String::operator+=(String & other)
{
	if (other.str == nullptr)
	{
		return *this;
	}
	int len = strlen(other.str) + 1;
	if (str != nullptr)
	{
		len += strlen(str);
	}
	char *temp = new char[len];
	memset(temp, 0, len);
	if (str != nullptr)
	{
		strcpy_s(temp, len, str);
		delete[] str;
	}
	strcat_s(temp, len, other.str);
	str = temp;
	return *this;
}

String  String::operator+(String & other)
{
	if (other.str == nullptr)
	{
		return *this;
	}
	int len = strlen(other.str) + 1;
	if (str != nullptr)
	{
		len += strlen(str);
	}
	String *temp = new String;
	temp->str = new char[len];
	memset(temp->str, 0, len);
	if (str != nullptr)
	{
		strcpy_s(temp->str, len, str);
	}
	strcat_s(temp->str, len, other.str);
	return *temp;
}

void String::output()
{
	cout << str << endl;
}
