#pragma once
class String
{
public:
	String(char *str=nullptr);
	String(String & other);
	~String();

	String & operator +=(String&other );
	String  operator +(String&other);

	void output();
private:
	char * str;
};

