// 1228.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include "Student.h"
using namespace std;

class A
{
public:
	 virtual void output()
	{
		cout << "A::output\n";
	}
};
class B	:public A
{
public:
	virtual void output()
	{
		cout << "B::output\n";
	}
};
int main1()
{
	A * P = new B;
	P->output();
    return 0;
}
int main()
{
	Student s1;
	s1.setName("С��");
	s1.setAge(18);
	s1.setSex("��");
	cout << s1 << endl;
	cout << s1.getAge() << endl;

	Student stu[3];
	stu[1]=
	return 0;
}
