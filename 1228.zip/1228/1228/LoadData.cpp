#include "stdafx.h"
#include "LoadData.h"


LoadData::LoadData()
{
}


LoadData::~LoadData()
{
}

int LoadData::read(Student stu[])
{
	return 0;
}



