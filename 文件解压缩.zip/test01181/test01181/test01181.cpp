// test01181.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "PackFile.h"
#include "UnPackFile.h"

int main1()
{	
	string fileName = "123.me";
	PackFile pack(fileName);
	pack.add("D:\\software\\010editor\\010EditorWin64Installer11.0.1.exe");
	pack.add("C:\\Users\\wh\\Desktop\\1.bmp");
	pack.add("C:\\Users\\wh\\Desktop\\1028\\01.13--01.15.docx");
	pack.save();
    return 0;
}

int main()
{
	string fileName = "123.me";
	UnPackFile pack(fileName);
	pack.save("D:\\temp\\0118");
	return 0;
}