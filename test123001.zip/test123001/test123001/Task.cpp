#include "stdafx.h"
#include "Task.h"


Task::Task()
{
}


Task::~Task()
{
}

void Task::input()
{
}

void Task::output() const
{
}
